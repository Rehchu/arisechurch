export const meta = {
  name: 'arise-audit-finders-2',
  description: 'Lean finder pass over the Arise Church element files not yet audited, plus two consolidated doc lenses (no verification stage; results are returned raw)',
  phases: [
    { title: 'Wave 1', detail: 'home, connect, footer, sermons, serve, ministries + backend/docs lens' },
    { title: 'Wave 2', detail: 'galleries x4, alexandria, classes, bible, service-times + facts/stale/email lens' }
  ]
}

const ROOT  = 'D:/projects/Arise Church Website'
const FIXED = ROOT + '/files2/arise-fixed-2026-08-23'
const SCR   = 'C:/Users/Rehch/AppData/Local/Temp/claude/D--projects-Arise-Church-Website/456ec4ba-6ded-42a6-8d3f-55dcfdade770/scratchpad'
const FACTS = SCR + '/FACTS.md'
const CRAWL = SCR + '/LIVE-CRAWL.md'
const SEV = ['blocker','bug','warning','note']

const FINDINGS = {
  type: 'object',
  properties: {
    findings: { type: 'array', items: { type: 'object', properties: {
      file: { type: 'string' }, line: { type: 'integer' },
      severity: { type: 'string', enum: SEV },
      category: { type: 'string' }, summary: { type: 'string' }, evidence: { type: 'string' }, fix: { type: 'string' }
    }, required: ['file','line','severity','category','summary','evidence','fix'] } }
  },
  required: ['findings']
}

const COMMON = 'Read ' + FACTS + ' first (facts sheet: canonical files, the Wix architecture, brand/content facts, severity scale) and ' + CRAWL + ' (today\'s live slug statuses). ' +
  'Be economical: read each file ONCE in full, avoid re-reading, do not diff against older versions. ' +
  'Report ONLY findings you can point to with a file path and line number (docs: path + heading, line 0), quoting the exact evidence. Empty list is valid. No subjective design preferences. Do not modify any file. ' +
  'Each element file is loaded by Wix in its own module scope, so cross-file identifier collisions are NOT an issue. Never quote rows from files/ArchivedFormSubmissions.csv. ' +
  'Known already (do NOT re-report): CMS text is written with innerHTML without escaping in applyContent() in every element; the Alexandria Sunday time conflict (10:00 in code/CMS vs 10:30 in docs); the "Sunday Sunday 10:30 AM" double label on Contact/Home; Anton used below 18px; the header/footer never receive data-content; hardcoded service times without data-ck hooks in About/Leaders/Events.'

function perFile(f) {
  return 'Audit ONE Velo custom element file for the Arise Church website (Wix): ' + FIXED + '/' + f + '.js (canonical version). ' + COMMON +
    ' Read the ENTIRE file top to bottom, then report, in this order: ' +
    '(1) anything that would visibly break on the PUBLISHED site: raw code/text leaking, malformed markup from template strings, a data-* path that throws (JSON parse without try/catch, undefined access), a fetch/URL that does not exist; ' +
    '(2) escaping of data-* / fetch / user input concatenated into innerHTML or attributes (other than the known applyContent pattern); ' +
    '(3) links: every href/src/action/fetch URL vs the crawl file; https; rel=noopener with target=_blank; a 404 slug is a blocker; ' +
    '(4) facts vs the facts sheet (times, addresses, phone, emails, names/titles, bare "Arise"); ' +
    '(5) accessibility and dark mode: heading order, real button/a, alt text, aria on toggles/dialogs/tabs, focus handling, prefers-reduced-motion, explicit background-color on every surface, #D6222D as small text on dark (compute the WCAG ratio with a node one-liner), tap targets under 24px; ' +
    '(6) lifecycle: connected/disconnected symmetry, listeners/intervals/observers cleaned up, re-attach, attributeChangedCallback before first render, style/link injection guards; ' +
    '(7) contract: observedAttributes and the parsed JSON shape vs the page code documented for this element in ' + ROOT + '/files/*-SETUP.md and ' + ROOT + '/files2/ARISE-HANDOFF.md sections 4-5; ' +
    '(8) anything else you can prove. Run "node --check" on the file first.'
}

const wave1 = [
  { key: 'arise-home', prompt: perFile('arise-home') },
  { key: 'arise-connect', prompt: perFile('arise-connect') },
  { key: 'arise-footer', prompt: perFile('arise-footer') },
  { key: 'arise-sermons', prompt: perFile('arise-sermons') },
  { key: 'arise-serve', prompt: perFile('arise-serve') },
  { key: 'arise-ministries', prompt: perFile('arise-ministries') },
  { key: 'lens:backend-docs', prompt: 'Audit the backend and page-code snippets embedded in the docs and the install instructions against the canonical element code. There are NO backend files in the zips; the code exists only inside the markdown under ' + ROOT + '/files (FORMS-SETUP.md, CONNECT-SETUP.md, EVENTS-SETUP.md, CMS-SETUP.md, CREATIVES-SETUP.md, SERVE-SETUP.md, HOME-VIDEO-SETUP.md, PAGECONTENT-SETUP.md, ALEXANDRIA-SETUP.md, CLASSES-SETUP.md, GALLERY-SETUP.md, SERMONS-LIVE-SETUP.md, SERMONS-SERIES-AUTO.md, INSTALL-ORDER.md, PAGES-CHECKLIST.md, ALL-PAGE-CODE.md) and ' + ROOT + '/files2/ARISE-HANDOFF.md section 5. ' + COMMON + ' Check: Velo API misuse (wix-crm-backend triggeredEmails.emailContact takes (emailId, contactId, options) -- a raw email address is not a contactId; wix-events.v2 queryEvents fields/status enums; wix-auth elevate; webMethod/Permissions/auth imports present in every file that uses them; is imgUrl, referenced by PAGECONTENT-SETUP and ALEXANDRIA-SETUP, defined in ANY doc?; is auth imported in CLASSES-SETUP getPrograms?); conflicting versions of the same backend file across docs (http-functions.js ROUTES vs ALLOWED vs handoff; events.jsw vs events.web.js and which import the page code uses; getPageContent {text,image} vs string|{text,imageUrl} -- which shape do the elements accept: read applyContent() in ' + FIXED + '/arise-home.js and T()/IMG() in ' + FIXED + '/arise-alexandria.js); the regex backslash issue in every copy of the email check; page-code element-ID assumptions; install instructions that contradict each other or the code (INSTALL-ORDER: Serve uses arise-form.js vs SERVE-SETUP: arise-serve.js; "11 elements" vs 21; PAGES-CHECKLIST says keep the native Wix contact form vs FORMS-SETUP says replace it; ALEXANDRIA-SETUP slug /alexandria vs live /arise-alexandria); every backend export imported by a page-code snippet exists somewhere; each page-code snippet sets exactly the attribute names the target element observes (grep observedAttributes in ' + FIXED + '). For docs cite path + heading with line 0. Mark unsure API claims medium/low confidence in the evidence.' }
]

const wave2 = [
  { key: 'galleries', prompt: 'Audit FOUR near-identical Velo gallery elements for the Arise Church website (Wix): ' + FIXED + '/arise-childrens.js, arise-youth.js, arise-outreach.js, arise-leadnetwork.js. ' + COMMON + ' Read arise-childrens.js in full, then run diff between it and each of the other three and read only the differing regions (the shared lightbox/mosaic code is byte-identical by design). Report findings with the correct file path for each file (a defect in shared code should be reported once per file it occurs in, same line numbers). Check the same eight areas as a normal element audit: visible breakage, escaping of data-photos/captions/alt/video URLs into innerHTML and attributes, links vs the crawl file, facts vs the facts sheet (Kerik youth ministers, Austin/Calloway Lead Network ministers, Impact Tioga), accessibility/dark mode (lightbox role=dialog, focus trap/return, Escape, arrow keys, reduced motion, alt text, explicit backgrounds, #D6222D small text on dark -- compute ratios), lifecycle (lightbox appended to body, keydown handler cleanup, re-attach), contract with GALLERY-SETUP.md page code ({src, videoId, alt, caption} objects; video renditions 1080p/720p/480p from video.wixstatic.com), and the CMS image keys (data-ci childrens.kids.photo etc. -- note the facts sheet: some CMS imageUrl rows use a c3b2d0_ prefix that the CDN answers 403, while the code fallback uses 1f9fa2_ URLs that load).' },
  { key: 'arise-alexandria', prompt: perFile('arise-alexandria') },
  { key: 'arise-classes', prompt: perFile('arise-classes') },
  { key: 'arise-bible', prompt: perFile('arise-bible') },
  { key: 'arise-service-times-final', prompt: perFile('arise-service-times-final') },
  { key: 'lens:facts-stale-email', prompt: 'Three small checks for the Arise Church Wix rebuild. ' + COMMON + ' (A) STALE FILES: in ' + ROOT + '/files, the JS files arise-pages.js, arise-hero.js, arise-events-sermons.js, arise-service-times.js and arise-service-times-v2.js are legacy and define the SAME custom element tag names as canonical files in ' + FIXED + ' (grep customElements.define in each); say what happens on Wix if a legacy file is still present in public/custom-elements/ and is selected or loaded alongside the canonical one, and which same-named files in files/ are older than the fixed set (cmp them). Also note whether the HTML mockups (FINAL-PREVIEW.html, arise-homepage-redesign.html, page-0*.html, pages-05-11.html, pages-ministries-leaders.html) carry a color-scheme meta / light-only rule (grep color-scheme) -- mockups are references, severity note. Flag ArchivedFormSubmissions.csv (50 real people\'s contact details) sitting in a shared zip, severity warning, do not quote rows. (B) EMAIL: compare ' + ROOT + '/files/EMAIL-TEMPLATES.html against ' + ROOT + '/files/EMAIL-BUILD-SPEC.md: forbidden #D6222D text on #0A0A0C (compute ratio), no phone number in any email, Email D has no button and no service-times row and Main Campus address only, subjects, variable names, button URLs exist per the crawl file, 600px width, Arial. (C) FACTS: grep all 21 canonical files for the Connect Groups SEASON dates and any other dated copy (hostBy September 2, "week of September 14") and say what a visitor sees now that it is 2026-09-14; grep for bare "Arise" not followed by Church/Creative/Hub/Alexandria/Bible/Red and report each with line; grep the data-ck/data-ci/data-ckrow keys used by the elements and compare with the key list in files/PageContent.csv (keys used by elements but absent from the CSV, and CSV keys nothing reads).' }
]

async function run(list, ph) {
  phase(ph)
  const res = await parallel(list.map(t => () =>
    agent(t.prompt, { label: 'find:' + t.key, phase: ph, schema: FINDINGS, effort: 'medium' })
      .then(r => ((r && r.findings) || []).map(f => Object.assign({}, f, { finder: t.key })))))
  const stats = list.map((t, i) => t.key + '=' + (res[i] ? res[i].length : 'FAILED'))
  log(ph + ' done: ' + stats.join(' '))
  return { findings: res.filter(Boolean).flat(), stats }
}

const a = await run(wave1, 'Wave 1')
const b = await run(wave2, 'Wave 2')
const findings = a.findings.concat(b.findings)
log('TOTAL raw findings: ' + findings.length)
return { stats: a.stats.concat(b.stats), findings }
