export const meta = {
  name: 'fix-arise-elements-wave',
  description: 'Apply the audited fixes to a subset of Arise Church custom-element files, then verify each file did not break',
  phases: [{ title: 'Fix' }, { title: 'Verify' }, { title: 'Repair' }],
}

const ROOT = 'D:/projects/Arise Church Website'
const WORK = ROOT + '/files2/arise-fixed-2026-09-14/custom-elements'
const ORIG = ROOT + '/files2/arise-fixed-2026-08-23'
const FINDINGS = 'C:/Users/Rehch/AppData/Local/Temp/claude/D--projects-Arise-Church-Website/456ec4ba-6ded-42a6-8d3f-55dcfdade770/scratchpad/code-findings.json'

const ALL_GROUPS = [
  { key: 'home', files: ['arise-home.js'] },
  { key: 'header-footer', files: ['arise-header.js', 'arise-footer.js'] },
  { key: 'contact-serve', files: ['arise-contact.js', 'arise-serve.js'] },
  { key: 'connect-form', files: ['arise-connect.js', 'arise-form.js'] },
  { key: 'leaders-ministries-about', files: ['arise-leaders.js', 'arise-ministries.js', 'arise-about.js'] },
  { key: 'events-sermons', files: ['arise-events.js', 'arise-sermons.js'] },
  { key: 'galleries', files: ['arise-childrens.js', 'arise-youth.js', 'arise-outreach.js', 'arise-leadnetwork.js'] },
  { key: 'misc', files: ['arise-alexandria.js', 'arise-creatives.js', 'arise-service-times-final.js', 'arise-bible.js'] },
]
const wanted = (args && args.groups) || ALL_GROUPS.map((g) => g.key)
const GROUPS = ALL_GROUPS.filter((g) => wanted.indexOf(g.key) > -1)
log('groups in this wave: ' + GROUPS.map((g) => g.key).join(', '))

const POLICY = `
You are editing Wix Velo custom-element files for the Arise Church website (arisecenla.church).
WORKING COPIES to edit: ${WORK}/<file>   (already copied from the originals)
ORIGINALS for reference, never modify: ${ORIG}/<file>
AUDIT FINDINGS (JSON keyed by file name; each has sev, line, cat, summary, fix): ${FINDINGS}
The user's instruction: "fix any issues in the existing codes, don't break them". Behaviour that works today must keep working exactly. Surgical edits only. Work efficiently: read each file once, plan all edits, apply them, check.

HARD RULES
1. Do not reformat, re-indent, rename classes/ids/attributes/tags, or reorder code. Match the file's existing style (mostly 'function' callbacks, 'const', string concatenation). Keep the file a single self-contained custom element; keep customElements.define(...). observedAttributes may only gain entries, never lose any.
2. Every existing feature stays (menus, popups, lightboxes, forms, fallbacks, rotation timers). If a finding's fix would change copy or facts that are an owner decision (Vanessa Sanders' title, dated sermon clips, Connect season dates, Thelma), do NOT apply it - list it as deferred.
3. After editing each file run: node --check "<file>" and fix any syntax error. Then grep that the file still contains customElements.define and the same tag name.
4. Add ONE line to the file's header comment: "Fixed 2026-09-14: <short list>". No other comment churn.
5. New helper functions must have a file-unique prefix (e.g. ahoEsc for home, aftEsc for footer) so nothing collides.
6. Do not touch <script src> / external resources; no new fonts; no new dependencies.
7. Keep syntax that iPhone Safari 15 and the Facebook in-app browser run (no optional chaining ?., no ??, no class fields, no static blocks). The files already avoid these.

FACTS (confirmed by the church 2026-09-14)
- Main campus Pineville: Sunday 10:30 AM. Glory Night Monday 7:00 PM. Wednesday 7:00 PM. Corporate Prayer Mon-Thu 5:00 AM.
- Alexandria campus: Sunday 10:00 AM (NOT 10:30). Wednesday 6:00 PM "Prayer". Wednesday 6:45 PM "Bible Study". Pastor Sheron calls those two rows "Prayer" and "Bible Study"; the files currently label them "Pre-Service Prayer" and "Midweek Service" - change those two labels to "Prayer" and "Bible Study".
- Emails: contact/serve/connect fallback arisenow.church@gmail.com; prayer fallback arisechurchprayer@gmail.com. Phone (318) 640-1865.
- CMS Page Content values are plain strings and carry the day: site.times.sunday.main = "Sunday 10:30 AM", site.times.sunday.second = "Sunday 10:00 AM", site.times.second.prayer = "Wednesday 6:00 PM", site.times.second.midweek = "Wednesday 6:45 PM", site.times.main.glorynight = "Monday 7:00 PM", site.times.main.midweek = "Wednesday 7:00 PM", site.times.main.prayer = "Mon-Thu 5:00 AM", site.campus.main / site.campus.second = full addresses, site.tagline = "#YouBelongHere", site.email.

POLICIES (apply where a finding or the list below asks for it)
A. CMS text stays innerHTML for [data-ck] (existing behaviour, CMS is admin-only) BUT stop building CSS selectors from the key. Replace the per-key querySelectorAll('[data-ck="' + k + '"]') pattern with a loop over root.querySelectorAll('[data-ck]') / '[data-ci]' / '[data-ckrow]' that reads el.getAttribute('data-ck') and looks the key up in the map. Keep each file's existing semantics (IMG src vs background-image, hidden rows via data-ckrow unhide when text exists). Quote background urls: 'url("' + String(v.image).replace(/["\\\\]/g, '') + '")'.
B. Values that arrive as JSON attributes (data-leaders, data-ministries, data-series-*, data-photos videoId/poster, data-news, data-culture) must be escaped before concatenation into HTML/attributes with the file's escape helper (add one if the file has none: function xxxEsc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}). Video/media IDs may instead be validated with /^[A-Za-z0-9_\\-]+$/ (drop the item if invalid).
C. Service-time sentences and rows become CMS-driven with data-ck hooks. Because the CMS value includes the day, a hooked span's default text must be the full "Sunday 10:30 AM" / "Sunday 10:00 AM" form and the sentence rewritten to read naturally around it, e.g. 'Join us <span data-ck="site.times.sunday.main">Sunday 10:30 AM</span> in Pineville or <span data-ck="site.times.sunday.second">Sunday 10:00 AM</span> in Alexandria'. Where a row has a label column and a value column (home / contact / alexandria campus rows, footer "Sunday" lines, header mobile panel), keep the label but, after applyContent has run, trim a leading day name from the value when the label already names that day, using this helper (rename with the file prefix):
   function xxxTrimDay(label, value) { var m = /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\\b[\\s,:\\-\\u2013\\u00b7]*/i.exec(value || ''); return (m && String(label || '').toLowerCase().indexOf(m[1].toLowerCase()) > -1) ? value.slice(m[0].length) : value; }
   Row LABELS also get hooks so they can be renamed from the CMS later: data-ck="<value key>.label" (e.g. data-ck="site.times.second.prayer.label" on the label span whose value span is data-ck="site.times.second.prayer"). The default label text stays in the markup, so nothing changes until such a row exists in the CMS.
D. Accessibility fixes from the findings: dialogs get role="dialog" aria-modal="true" and an accessible name, remember the opener and restore focus on close, keep Tab inside while open (simple first/last focusable wrap); form status notes get role="status" aria-live="polite"; required inputs get aria-required="true"; on validation failure set aria-invalid="true" and aria-describedby to the hint's id (give hints ids), clear on success; success panels get tabindex="-1" and receive focus; tab widgets get role="tablist"/"tab"/"tabpanel" with aria-controls/aria-labelledby and Left/Right/Home/End keys. Do not change layout or copy while doing this.
E. Brand typography: Anton never below 18px - where a finding names a smaller Anton size, either raise it to 18px or switch that rule to the file's existing Oswald label treatment (font-family:'Oswald',Helvetica,Arial,sans-serif;font-weight:600;letter-spacing:.16em) as the finding suggests. Do not change other sizes.
F. Lifecycle: an element removed and re-attached by Wix must rebuild cleanly (timers restarted or observers re-observed, body-level panels re-appended), and re-setting an attribute to an empty list must clear timers/listeners first.

RETURN a JSON object: { changes: [{file, finding_line, what}], deferred: [{file, finding_line, why}], syntax_ok: [file...], notes: string }.
`

const SPECIFIC = {
  'home': `Findings for arise-home.js plus: (1) fillCulture(): when the data-culture object has heading / kicker strings, write them with textContent into the culture h2 / kicker (fallback to the current hardcoded text when absent). (2) fillNews(): clear this._newsTimer and remove the enter/leave hover listeners at the top, before the empty-items return. (3) re-attach path: re-observe the culture video with the IntersectionObserver (or rebuild it) and restart the news rotation if items exist. (4) escape/validate videoId and poster from data-culture, data-news, data-photos. (5) lightbox: role=dialog, aria-modal, aria-label="Photo viewer", focus return, Tab containment. (6) campus rows: label hooks (site.times.sunday.main.label, site.times.sunday.second.label, site.times.second.prayer.label, site.times.second.midweek.label, and the main-campus rows' keys if they exist), rename the Alexandria labels to "Prayer" / "Bible Study", and apply TrimDay after applyContent. (7) applyContent per policy A.`,
  'header-footer': `arise-header.js: (1) applyContent must also search this._panel (the mobile menu appended to document.body); use roots = [this, this._panel]. (2) In the panel meta block hook the two Sunday lines: '<b data-ck="site.times.sunday.main">Sunday 10:30 AM</b><br>Pineville<br><b data-ck="site.times.sunday.second">Sunday 10:00 AM</b><br>Alexandria' and Glory Night '<b data-ck="site.times.main.glorynight.label">Glory Night</b><br><span data-ck="site.times.main.glorynight">Monday 7:00 PM</span> &middot; Main Campus' (keep the phone link). (3) Anton floor: wordmark/panel title/mobile links at 15-17px -> 18px. (4) Mobile menu open: set inert on document.body children other than the panel (guard: if ('inert' in HTMLElement.prototype)) and clear on close; keep the existing focus return. (5) applyContent per policy A (keep innerHTML). arise-footer.js: (1) data-ck="site.tagline" on the #YouBelongHere span. (2) The "aft__when" lines: keep '<b>Sunday</b>' labels but apply TrimDay to the hooked spans after applyContent, OR restructure to '<span data-ck="site.times.sunday.main">Sunday 10:30 AM</span> Pineville' - pick one and keep the visual the same. (3) Bottom strip: '<span><span data-ck="site.times.sunday.main">Sunday 10:30 AM</span> Pineville &middot; <span data-ck="site.times.sunday.second">Sunday 10:00 AM</span> Alexandria</span>'. (4) applyContent per policy A.`,
  'contact-serve': `arise-contact.js: (1) applyContent per policy A; (2) campus rows: hook the main-campus values (site.times.main.glorynight, site.times.main.midweek, site.times.main.prayer) and every label (".label" keys); rename the two Alexandria labels to "Prayer" and "Bible Study"; apply TrimDay after applyContent so "Sunday" + "Sunday 10:30 AM" renders as "Sunday | 10:30 AM"; (3) Anton 13px card labels -> the Oswald kicker treatment; (4) external links (Directions, socials) target="_blank" rel="noopener", internal slugs keep _top; (5) form a11y per policy D; (6) fix the install header comment (the element DOES include the form). arise-serve.js: form a11y per policy D (aria-live note, hint ids + aria-describedby, aria-invalid, focus the .done block with tabindex=-1); nothing else.`,
  'connect-form': `arise-connect.js: (1) placeholder color alpha .34 -> .55; (2) form a11y per policy D; (3) tabs: ids on panels, aria-controls, role=tabpanel + aria-labelledby, Left/Right/Home/End keys; (4) the Host tab label / any other place that prints the host-by date gets data-ck="connect.season.hostby" like the card already has (keep SEASON constants as fallbacks); (5) applyContent per policy A. Leave the dates themselves. arise-form.js: (1) per-form fallback email in FORMS (prayer: arisechurchprayer@gmail.com, contact/serve: arisenow.church@gmail.com) used in the failure message; (2) a11y per policy D (role=status on #afmNote, hint ids, aria-invalid/aria-describedby, focus the success panel).`,
  'leaders-ministries-about': `arise-leaders.js: (1) escape name/role/bio/photo from data-leaders (policy B); (2) featured handling: const feats = LIST.filter(l => l.feat); const lead = feats[0]; const rest = LIST.filter(l => l !== lead); (3) the CTA sentence with both Sunday times -> policy C hooks; (4) applyContent per policy A. arise-ministries.js: (1) add overflow-x:hidden to the root wrapper rule that uses width:100vw; (2) escape title/cat/link/img (policy B); (3) normalise img: if it starts with 'wix:image://v1/' rewrite to 'https://static.wixstatic.com/media/' + id (id = text between 'v1/' and the next '/' or '#'); (4) CTA sentence hooks (policy C); (5) applyContent per policy A. Do NOT add the logo field. arise-about.js: (1) Visit CTA times -> policy C hooks; (2) We Believe / We Promise popups: role=dialog aria-modal aria-labelledby (ids on their h2), aria-haspopup="dialog" aria-controls on the triggers, focus return to the trigger, Tab containment (policy D); (3) applyContent per policy A.`,
  'events-sermons': `arise-events.js: (1) FALLBACK event: add endsAt: '2026-11-01T17:30:00-05:00' and in the data getter return {upcoming: [], past: []} when Date.now() > Date.parse(endsAt) (so the built-in Outpour card disappears after it ends); (2) when ctaEnabled === false render '<span class="btn btn--off" aria-disabled="true">Sold Out</span>' (no href) - keep the existing btn--off styling; (3) Anton floors (h3 15-18px -> clamp(18px,1.6vw,22px); .arch__t h3 -> 18px; .meta__r .lbl -> the Oswald label treatment); (4) empty-state sentence times -> policy C hooks; (5) applyContent per policy A; (6) escape CMS/JSON-sourced strings in cards if not already. arise-sermons.js: (1) applyLive(): compute the target iframe src and only assign when it differs from the current src; same for the badge; (2) series band hidden by default (display:none / hidden attribute in the built markup) and shown only when data-series-active === 'true'; keep the hardcoded title as the fallback content of the band; (3) applySeries(): escape title/line/link/button (policy B) - build the heading with a real <br> between title and line; (4) header comment "PAST SERMONS" -> "SERMONS"; (5) CTA times if any -> policy C; (6) applyContent per policy A.`,
  'galleries': `All four files share the same lightbox and gallery code. For each: (1) escape/validate p.videoId (and src/alt if not already) in fillGallery and the lightbox (policy B); (2) lightbox: role=dialog aria-modal aria-label="Photo viewer", remember document.activeElement on open and focus it on close, contain Tab (policy D); (3) the sentence with both Sunday times -> policy C hooks; (4) applyContent per policy A. arise-outreach.js and arise-leadnetwork.js additionally: the two stray statements 'this.fillGallery();' and 'this.applyContent();' were pasted INSIDE a .map() callback after its return (outreach ~line 251, leadnetwork ~line 322) - delete them from inside the callback (leave '}).join('') +' intact) and call this.fillGallery(); this.applyContent(); once, right after this._wire() in connectedCallback's first-build path (check the childrens/youth files for the correct placement and mirror it). Verify with node --check and by reading connectedCallback that on first build fillGallery and applyContent each run exactly once.`,
  'misc': `arise-alexandria.js: (1) header comment path /alexandria -> /arise-alexandria; (2) time rows: labels 'Prayer' and 'Bible Study' instead of 'Pre-Service Prayer' / 'Midweek Service'; give label cells data-ck="<key>.label" hooks and value cells data-ck hooks if not present; apply TrimDay (label 'Sunday Service' + value 'Sunday 10:00 AM' -> '10:00 AM'); (3) address: T('alexandria.address') || T('site.campus.second'); (4) applyContent per policy A. Leave Vanessa's title and city (owner decision). arise-creatives.js: (1) Anton floors (tile number badge, switcher, h3) per policy E; (2) member match: const key = function(s){return String(s||'').trim().toLowerCase();}; team = members.filter(m => key(m.department) === key(dept.name) || key(m.department) === key(dept.slug)); (3) applyContent per policy A. arise-service-times-final.js: (1) observedAttributes ['data-content'] + attributeChangedCallback -> applyContent that searches both this and this._panel (policy A); (2) panel content: replace the single '10:30 AM' + 'Both campuses' with two rows: '<p class="ast-time"><span data-ck="site.times.sunday.main">Sunday 10:30 AM</span> <small>Pineville</small></p><p class="ast-time"><span data-ck="site.times.sunday.second">Sunday 10:00 AM</span> <small>Alexandria</small></p>' keeping the note line 'Come as you are' (adjust CSS minimally so both rows fit the 344px panel); (3) re-mount: in disconnectedCallback set this._built = false after removing the panel and listeners so connectedCallback rebuilds, and make sure no duplicate document listeners remain; (4) give the panel an id, set aria-controls on the button, move focus to the panel (tabIndex=-1) on open. arise-bible.js: only the header comment: state that the Bible Search page needs no page code and that this file must exist at public/custom-elements/arise-bible.js; nothing else.`,
}

const FIX_SCHEMA = {
  type: 'object',
  properties: {
    changes: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, finding_line: { type: 'string' }, what: { type: 'string' } }, required: ['file', 'what'] } },
    deferred: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, finding_line: { type: 'string' }, why: { type: 'string' } }, required: ['file', 'why'] } },
    syntax_ok: { type: 'array', items: { type: 'string' } },
    notes: { type: 'string' },
  },
  required: ['changes', 'deferred', 'syntax_ok', 'notes'],
}
const VERIFY_SCHEMA = {
  type: 'object',
  properties: {
    ok: { type: 'boolean' },
    problems: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, line: { type: 'string' }, problem: { type: 'string' }, how_to_fix: { type: 'string' } }, required: ['file', 'problem', 'how_to_fix'] } },
    unaddressed: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, finding_line: { type: 'string' }, note: { type: 'string' } }, required: ['file', 'note'] } },
    summary: { type: 'string' },
  },
  required: ['ok', 'problems', 'unaddressed', 'summary'],
}

const fixPrompt = (g, extra) => `${POLICY}
FILES IN THIS TASK: ${g.files.join(', ')}
SPECIFIC INSTRUCTIONS: ${SPECIFIC[g.key]}
${extra || ''}
Work file by file: Read the whole working copy, Read its findings from the JSON, plan the edits, apply them with Edit, run node --check, re-read the changed regions to confirm string concatenations and braces are balanced.`

const verifyPrompt = (g, fix) => `You are a skeptical reviewer for Wix Velo custom-element files. Your job: prove the edits did NOT break anything, and that every applicable finding was handled.
WORKING COPIES (edited): ${WORK}/<file>    ORIGINALS: ${ORIG}/<file>    FINDINGS JSON: ${FINDINGS}
FILES: ${g.files.join(', ')}
The fixer reported: ${JSON.stringify(fix).slice(0, 6000)}
POLICY the fixer had to follow (summarised): surgical edits only; no renames/reformatting; observedAttributes may only grow; customElements.define kept; iPhone-safe syntax (no ?., ??, class fields); CMS text stays innerHTML but key lookups no longer build CSS selectors; JSON-sourced values escaped; service-time sentences hooked with data-ck spans whose default text is the full "Sunday 10:30 AM" form; label hooks "<key>.label"; Alexandria rows labelled "Prayer" and "Bible Study"; a11y additions must not change layout/copy; owner-decision content deferred.
DO THIS for each file:
1. Run: node --check "<working copy>".
2. Run a diff (Bash: diff "<orig>" "<work>") and read EVERY hunk. For each hunk decide: intended by a finding/policy? could it break a feature (unbalanced string concatenation, a helper used before defined, 'this' inside a plain function callback, removed listener, changed selector/class, duplicate id, a hook whose default text no longer matches the visible copy, TrimDay applied to the wrong node)?
3. grep that customElements.define and the tag name are intact; that observedAttributes is a superset of the original; that no '?.', '??' or class fields were introduced.
4. For each finding of that file in the JSON (skip sev 'note'): confirm it is addressed in the working copy (quote the line) or legitimately deferred.
5. Mentally simulate: first connectedCallback build -> attributes set later (data-content then data-* JSON) -> re-set to empty -> element removed and re-attached. Note anything that would throw or double-render.
Return {ok, problems, unaddressed, summary}. ok=false if ANY problem could break a page. Be concrete: file, line, what, how to fix.`

phase('Fix')
const results = await pipeline(
  GROUPS,
  (g) => agent(fixPrompt(g), { label: `fix:${g.key}`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'medium' }),
  (fix, g) => agent(verifyPrompt(g, fix), { label: `verify:${g.key}`, phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'medium' })
    .then((v) => ({ fix, verify: v })),
  async (r, g) => {
    if (!r || !r.verify || r.verify.ok) return { ...r, repaired: false }
    log(`repairing ${g.key}: ${r.verify.problems.length} problem(s)`)
    const repair = await agent(fixPrompt(g, `A reviewer found these problems with the current working copies - fix exactly these (and any unaddressed findings listed) without undoing the other edits:\n${JSON.stringify(r.verify.problems, null, 1)}\nUNADDRESSED: ${JSON.stringify(r.verify.unaddressed, null, 1)}`), { label: `repair:${g.key}`, phase: 'Repair', schema: FIX_SCHEMA, effort: 'medium' })
    const recheck = await agent(verifyPrompt(g, repair), { label: `recheck:${g.key}`, phase: 'Repair', schema: VERIFY_SCHEMA, effort: 'medium' })
    return { ...r, repaired: true, repair, recheck }
  }
)
return results.map((r, i) => ({ group: GROUPS[i].key, ...r }))