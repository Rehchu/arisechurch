export const meta = {
  name: 'arise-site-audit',
  description: 'Exhaustive static audit of the Arise Church Velo custom elements, setup docs, backend snippets and CSVs, with adversarial verification of every finding',
  phases: [
    { title: 'Find', detail: '21 per-file finders + 10 cross-cutting lenses' },
    { title: 'Verify', detail: 'adversarial refuters per finding (1-2 lenses by severity)' },
    { title: 'Critique', detail: 'completeness critic, then one gap round' }
  ]
}

const ROOT  = 'D:/projects/Arise Church Website'
const FIXED = ROOT + '/files2/arise-fixed-2026-08-23'
const SCR   = 'C:/Users/Rehch/AppData/Local/Temp/claude/D--projects-Arise-Church-Website/456ec4ba-6ded-42a6-8d3f-55dcfdade770/scratchpad'
const FACTS = SCR + '/FACTS.md'
const CRAWL = SCR + '/LIVE-CRAWL.md'

const FILES = ['arise-about','arise-alexandria','arise-bible','arise-childrens','arise-classes','arise-connect',
  'arise-contact','arise-creatives','arise-events','arise-footer','arise-form','arise-header','arise-home',
  'arise-leaders','arise-leadnetwork','arise-ministries','arise-outreach','arise-sermons','arise-serve',
  'arise-service-times-final','arise-youth']

const SEV = ['blocker','bug','warning','note']

const FINDINGS = {
  type: 'object',
  properties: {
    findings: { type: 'array', items: { type: 'object', properties: {
      file: { type: 'string', description: 'path of the file or doc (relative to the project root is fine)' },
      line: { type: 'integer', description: '1-based line number; 0 if a doc heading is cited instead' },
      severity: { type: 'string', enum: SEV },
      category: { type: 'string', description: 'short kebab-case tag, e.g. dead-link, escaping, wrong-fact, docs-mismatch, a11y, contrast, lifecycle, backend-api, stale-file, privacy' },
      summary: { type: 'string', description: 'one sentence: what is wrong' },
      evidence: { type: 'string', description: 'the exact quoted line(s) / doc text proving it, plus any computed value (e.g. contrast ratio)' },
      fix: { type: 'string', description: 'the minimal concrete fix' }
    }, required: ['file','line','severity','category','summary','evidence','fix'] } }
  },
  required: ['findings']
}

const VERDICT = {
  type: 'object',
  properties: {
    refuted: { type: 'boolean' },
    confidence: { type: 'string', enum: ['high','medium','low'] },
    reason: { type: 'string' },
    corrected_severity: { type: 'string', enum: SEV, description: 'only if the rated severity is wrong' },
    corrected_fix: { type: 'string', description: 'only if the proposed fix is wrong or unsafe' }
  },
  required: ['refuted','confidence','reason']
}

const COMMON = 'Read ' + FACTS + ' first (facts sheet: which files are canonical, the Wix architecture, brand/content facts, severity scale). ' +
  'Read ' + CRAWL + ' for today\'s live-site slug statuses and homepage facts. ' +
  'Report ONLY findings you can point to with a file path and line number (for docs: path + heading, line 0), quoting the exact evidence. ' +
  'Do not pad; an empty list is a valid answer. Do not report subjective design preferences as bugs. Do not modify any file. ' +
  'Assume, as Wix does, that each custom-element file is loaded in its own module scope, so top-level identifier collisions across files are NOT an issue. ' +
  'Never quote rows from files/ArchivedFormSubmissions.csv (real people\'s contact details).'

const perFile = FILES.map(f => ({
  key: f,
  prompt: 'You are auditing ONE Velo custom element file for the Arise Church website (Wix). ' +
    'File: ' + FIXED + '/' + f + '.js (the canonical, current version). ' +
    'An older version may exist at ' + ROOT + '/files/' + f + '.js: diff them (git diff --no-index, or diff) to see what the Aug 23 fix pass changed, ' +
    'and check that the fixes AUDIT-REPORT.md (' + ROOT + '/files2/AUDIT-REPORT.md, the numbered fixes and the per-file table) claims for this file are actually present in the canonical file. ' +
    COMMON + ' ' +
    'Then read the ENTIRE canonical file top to bottom (it is a few hundred lines; read all of it, not excerpts) and look for, in this order: ' +
    '(1) anything that would visibly break on the PUBLISHED Wix site: raw code/text leaking into the page, HTML built with missing or unbalanced tags, template strings that produce malformed markup, a data-* attribute path that throws (JSON parse without try/catch, undefined access), customElements.define not at top level, module-top-level use of document/window that would run before the DOM exists, a fetch to a URL that does not exist; ' +
    '(2) escaping: every place data from data-* attributes, fetch responses or user input is concatenated into innerHTML or into an attribute value -- is it passed through the file\'s escape helper? unescaped = bug (blocker if a stray quote/angle bracket in CMS text would break a form or lightbox); ' +
    '(3) links: every href/src/action/fetch URL -- compare each internal slug with the crawl file; https on external URLs; rel=noopener with target=_blank; a link to a 404 slug is a blocker; ' +
    '(4) facts: service times, campus addresses, phone, emails, leader names/titles, bare "Arise" vs "Arise Church" -- compare with the facts sheet; wrong fact = bug; a fact that conflicts between sources = warning naming both sources; ' +
    '(5) accessibility and dark mode: heading order, real button/a elements for controls, alt text, aria on toggles/dialogs/tabs, focus handling for overlays, prefers-reduced-motion, explicit background-color on every surface, #D6222D used for small text on a dark background (should be #DB3F48 -- COMPUTE the WCAG contrast ratio with a short node one-liner, do not guess), Anton below 18px, tap targets under 24px in the CSS; ' +
    '(6) lifecycle: connected/disconnected symmetry, listeners/intervals/observers cleaned up, re-attach behaviour, attributeChangedCallback before first render, duplicate style/link injection guards; ' +
    '(7) contract: observedAttributes and the JSON shape the file parses vs what the documented page code sets (find the *-SETUP.md in ' + ROOT + '/files that covers this element, and ARISE-HANDOFF.md sections 4-5 in ' + ROOT + '/files2) -- mismatched attribute names or shapes = bug; ' +
    '(8) anything else you can prove. Run "node --check" on the file first.'
}))

const lenses = [
  { key: 'lens:install-docs', prompt: 'Cross-check the install/setup documentation against the canonical element code. Docs: ' + ROOT + '/files/INSTALL-ORDER.md, PAGES-CHECKLIST.md, ALL-PAGE-CODE.md, FINAL-BUILD-PLAN.md, VELO-CMS-GUIDE.md, BUILD-01-HOME.md, every *-SETUP.md, and ' + ROOT + '/files2/ARISE-HANDOFF.md (newest, Aug 23 2026 -- it wins on conflicts). Code: ' + FIXED + '/*.js. ' + COMMON + ' Find: (a) tag names, file names, folder paths, attribute names/values, element IDs, backend file names/exports and page-code imports that disagree between docs, or between a doc and the code (examples to check, not a complete list: INSTALL-ORDER says Serve uses arise-form.js with data-form=serve while SERVE-SETUP/HANDOFF say arise-serve.js; events.jsw vs events.web.js; two different getPageContent implementations; "11 elements" vs 21 files; PAGES-CHECKLIST says keep the native Wix contact form while FORMS-SETUP says replace it); (b) instructions that are stale per the crawl (renames already done, pages that no longer exist); (c) contradictions between docs on the same topic. For each, name both sources with heading/line and say which one the CODE actually matches. Severity: an instruction that would make the install fail or install the wrong file = bug; stale-but-harmless = warning or note.' },
  { key: 'lens:backend', prompt: 'Audit every backend and page-code snippet embedded in the docs (there are NO backend files in the zips; the code exists only inside the markdown). Sources under ' + ROOT + '/files: FORMS-SETUP.md, CONNECT-SETUP.md, EVENTS-SETUP.md, CMS-SETUP.md, CREATIVES-SETUP.md, SERVE-SETUP.md, HOME-VIDEO-SETUP.md, PAGECONTENT-SETUP.md, ALEXANDRIA-SETUP.md, CLASSES-SETUP.md, GALLERY-SETUP.md, SERMONS-LIVE-SETUP.md, SERMONS-SERIES-AUTO.md, ALL-PAGE-CODE.md, VELO-CMS-GUIDE.md; and ' + ROOT + '/files2/ARISE-HANDOFF.md section 5. ' + COMMON + ' For each snippet check: Velo API misuse (for example wix-crm-backend triggeredEmails.emailContact takes (emailId, contactId, options) -- a raw email address is not a contactId; wix-events.v2 queryEvents shape, fields and status enums; wix-auth elevate usage; webMethod/Permissions/auth imports present in every file that uses them; is imgUrl, referenced by PAGECONTENT-SETUP and ALEXANDRIA-SETUP, defined in ANY doc?; is "auth" imported in CLASSES-SETUP getPrograms?); conflicting versions of the same backend file across docs (http-functions.js ROUTES vs ALLOWED vs the handoff version; getPageContent returning {text,image} vs string|{text,imageUrl}); which data-content shape do the elements ACTUALLY accept -- read applyContent() in ' + FIXED + '/arise-home.js and T()/IMG() in ' + FIXED + '/arise-alexandria.js and say which doc version is compatible with which element; the email regex backslash issue (\\\\s vs \\s) in every copy; page-code element-ID assumptions; error handling; anything the handoff says is still pending (ALLOWED list). Also verify every backend export a page-code snippet imports exists in some doc, and that each page-code snippet sets exactly the attribute names the target element observes (grep observedAttributes). Mark anything you are unsure about as medium/low confidence inside the evidence text.' },
  { key: 'lens:facts', prompt: 'Audit content facts across ' + FIXED + '/*.js, ' + ROOT + '/files/PageContent.csv and the docs in ' + ROOT + '/files and ' + ROOT + '/files2. ' + COMMON + ' Extract every occurrence of: service times (Sunday/Monday/Wednesday/prayer, each campus), campus addresses, phone, email addresses, leader names and titles, the Alexandria pastor, the Connect Groups SEASON dates, "Past Sermons" vs "Sermons" labels, bare "Arise" vs "Arise Church", "TBA", Tioga vs Pineville, Prophet vs Pastor, the hero copy, the hashtag/tagline. Build yourself a table of where each appears and what it says, then report every disagreement with both locations. Specifically settle: what does EACH element and the CSV say the SECOND campus Sunday time is (10:00 vs 10:30) and what do the docs say; is any SEASON date already in the past relative to 2026-09-13 (hostBy September 2) and what does the element display then; does the CSV key set match the data-ck/data-ci/data-ckrow keys in the elements (list keys used by elements but missing from the CSV, and CSV keys no element reads). Keep PII out.' },
  { key: 'lens:claimed-fixes', prompt: 'Verify ' + ROOT + '/files2/AUDIT-REPORT.md: its 17 numbered fixes, its per-file status table, and its "8 untouched" claim, against reality. For each fix identify the file(s), diff ' + ROOT + '/files/<name>.js against ' + FIXED + '/<name>.js (git diff --no-index or diff), and confirm the described change is present in the canonical file with line evidence. Also look for regressions: anything present in the original but missing in the fixed version that is not one of the described removals, and any described fix that was applied to some but not all of the files it names (e.g. the four gallery files). ' + COMMON + ' Report each fix as present/absent/partial (absent or partial = bug; regression = bug), and note any claim in the report that the code contradicts.' },
  { key: 'lens:stale-files', prompt: 'Audit the file inventory for stale, duplicate and superseded artefacts that could be installed by mistake. Inventory: ' + ROOT + '/files (75 files) and ' + ROOT + '/files2 (ARISE-HANDOFF.md, AUDIT-REPORT.md, arise-fixed-2026-08-23/ with 21 js). ' + COMMON + ' Check: (a) which JS files in files/ are superseded by same-named files in the fixed set and what differs at a glance; (b) legacy files that define the SAME custom element tag names as canonical files (arise-pages.js, arise-events-sermons.js, arise-hero.js, arise-service-times.js, arise-service-times-v2.js) -- what happens on Wix if a legacy file is still in public/custom-elements/ and gets selected, or both get loaded on one page (customElements.define twice throws); (c) the HTML mockups (FINAL-PREVIEW.html, arise-homepage-redesign.html, page-0*.html, pages-05-11.html, pages-ministries-leaders.html, arise-design-system.html, service-times-*.html): do they still match the element code (hero sub-line, nav, slugs), do they carry the color-scheme/dark-mode protections the facts sheet requires -- treat mockups as references, severity note/warning only; (d) the three service-times versions and which is canonical; (e) docs that are fully superseded by ARISE-HANDOFF.md; (f) ArchivedFormSubmissions.csv sitting unprotected in a folder that gets zipped and shared (privacy warning, do not quote rows). Produce a recommended "current vs archive" split as your last finding (severity note).' },
  { key: 'lens:security', prompt: 'Security and privacy lens over all 21 files in ' + FIXED + '. ' + COMMON + ' For every file: find every innerHTML/insertAdjacentHTML/outerHTML assignment and every string-built attribute; trace each interpolated value back to its source (constant, data-* JSON, fetch response, user input); flag any that reaches markup without the file\'s escape helper (CMS editors are not attackers, but a stray quote or angle bracket in a name/caption will break the page, and Portfolio titles/captions are free text). Check: rel=noopener on target=_blank; http:// links; mailto exposure; the form POST bodies (what is sent, any field the backend will not accept); client-side vs backend validation parity; the external fetch in arise-bible.js to bible-api.com (response handling, error UI, no eval/innerHTML of raw API text); inline event handlers; postMessage; localStorage. Also flag the ArchivedFormSubmissions.csv PII exposure (do not quote rows).' },
  { key: 'lens:a11y-brand', prompt: 'Accessibility, forced-dark-mode and brand-compliance lens over all 21 files in ' + FIXED + '. ' + COMMON + ' For each file check: heading hierarchy inside the element (page-level elements should carry exactly one h1; header/footer/service-times/form none; no skipped levels), real button/a elements for anything clickable, alt text on every img (from content, not filenames), aria-expanded/aria-controls/aria-modal/role=dialog on toggles, menus, lightboxes and popups, focus management (trap and return) for overlays, Escape to close, prefers-reduced-motion for animations/carousels/autoplay, keyboard reachability of carousels and tabs, labels bound to inputs, error messages announced (aria-live), tap targets at least 24px (read the CSS), and text contrast for every hardcoded colour pair -- COMPUTE the WCAG ratios with a node one-liner, do not estimate; #D6222D on #0A0A0C or #060608 for text below about 24px is a bug (brand rule: #DB3F48), Anton below 18px, explicit background-color on every section/surface, any second accent colour or decorative gradient (brand rule: one accent).' },
  { key: 'lens:links', prompt: 'Link audit over all 21 files in ' + FIXED + '. ' + COMMON + ' Extract EVERY href, src, action, fetch URL, iframe src and window.open target, including ones built by concatenation (read the code, not just grep). Classify each as internal slug / external / mailto / tel / anchor. For each internal slug look it up in the crawl file: 404 there = blocker; not in the crawl = warning tagged unverified (list them so they can be crawled). For external URLs check https, rel=noopener with target=_blank, and that YouTube / Google Maps / Spotify / Tithe.ly URLs are well-formed (embeds use /embed/; channel UCGS9j7B_prcJkbTNgzlGrKg; livestream playlist UULVGS9j7B_prcJkbTNgzlGrKg). Check the header NAV array plus the footer plus ministry tiles cover every rebuilt page that is 200 live (is /arise-alexandria reachable from anywhere? /creative-arts? /connect-groups? /classes? /lead-network?) and list orphans. Note target=_top consistency (needed because Editor/Preview iframe the element) as inconsistency only.' },
  { key: 'lens:email', prompt: 'Compare ' + ROOT + '/files/EMAIL-TEMPLATES.html against ' + ROOT + '/files/EMAIL-BUILD-SPEC.md. ' + COMMON + ' Check colours (#D6222D text on #0A0A0C is forbidden in the spec -- must be #DB3F48; compute ratios), no phone number in any email, Email D has no button and no service-times row and Main Campus address only, subjects, variable names, button URLs (do they exist per the crawl file?), 600px width, Arial. Report mismatches (warning) and dead links (bug).' },
  { key: 'lens:runtime', prompt: 'Runtime-behaviour lens over all 21 files in ' + FIXED + ', with the Wix loading model in mind: each element file is its own module; the element connects and renders its built-in fallback FIRST, then page code sets data-* attributes 300ms or more later; Wix may detach and re-attach elements; Editor/Preview iframe the element so window.location is not the site URL there; only the published site is real. ' + COMMON + ' For each file trace: the connectedCallback guard (this._b / this._built) and what happens on re-attach after disconnectedCallback (are body-mounted panels, document listeners, intervals, observers restored?); attributeChangedCallback firing before connectedCallback when the attribute is present in the markup -- does it touch nodes that do not exist yet?; JSON parsing of every data-* attribute; every setInterval/setTimeout/requestAnimationFrame/IntersectionObserver/matchMedia listener -- cleaned up?; listener stacking when an attribute update re-renders (are handlers re-added on each render?); "this.innerHTML =" on an attribute change that would wipe a form a visitor is typing into (e.g. data-content arriving late); scroll-lock restoration; error paths that leave an overlay or spinner stuck. Report concrete, reproducible defects with line numbers; "could theoretically" with no trigger path is at most a note.' }
]

const tasks = [...perFile, ...lenses]

/* ---- Find (barrier: dedup across finders halves the verification cost) ---- */
phase('Find')
log('Launching ' + tasks.length + ' finders (' + perFile.length + ' per-file + ' + lenses.length + ' lenses)')
const rawResults = await parallel(tasks.map(t => () =>
  agent(t.prompt, { label: 'find:' + t.key, phase: 'Find', schema: FINDINGS })
    .then(r => ((r && r.findings) || []).map(f => Object.assign({}, f, { finder: t.key })))
))
const finderStats = tasks.map((t, i) => t.key + '=' + (rawResults[i] ? rawResults[i].length : 'null'))
const raw = rawResults.filter(Boolean).flat()
log('Raw findings: ' + raw.length + ' | ' + finderStats.join(' '))

function base(p) { return String(p || '').replace(/\\/g, '/').split('/').pop().toLowerCase() }
function sevRank(s) { return SEV.indexOf(s) < 0 ? 9 : SEV.indexOf(s) }
function dedupe(list, seen) {
  const sorted = list.slice().sort((a, b) => base(a.file) < base(b.file) ? -1 : base(a.file) > base(b.file) ? 1 : (a.line || 0) - (b.line || 0))
  const out = []
  for (const f of sorted) {
    const key = base(f.file) + ':' + (f.line || 0) + ':' + (f.category || '')
    if (seen && seen.has(key)) continue
    const prev = out[out.length - 1]
    if (prev && base(prev.file) === base(f.file) && prev.category === f.category && f.line > 0 && prev.line > 0 && Math.abs(prev.line - f.line) <= 2) {
      prev.finders = Array.from(new Set(prev.finders.concat(f.finder)))
      if (sevRank(f.severity) < sevRank(prev.severity)) { prev.severity = f.severity; prev.summary = f.summary; prev.evidence = f.evidence; prev.fix = f.fix }
      continue
    }
    out.push(Object.assign({}, f, { finders: [f.finder], key }))
  }
  return out
}
const seen = new Set()
let deduped = dedupe(raw)
deduped.forEach(f => seen.add(f.key))
log('After dedup: ' + deduped.length + ' distinct findings')

/* ---- Verify ------------------------------------------------------------- */
function lensesFor(sev) {
  if (sev === 'blocker' || sev === 'bug') return ['exists', 'impact']
  return ['exists']
}
function verifyPrompt(f, lens) {
  const desc = Object.assign({}, f); delete desc.finders; delete desc.key
  return 'Adversarially verify ONE audit finding about the Arise Church Wix rebuild. You are the "' + lens + '" refuter. ' + COMMON +
    ' Project root: ' + ROOT + ' ; canonical element files: ' + FIXED + ' . FINDING (JSON): ' + JSON.stringify(desc) + ' . ' +
    'Lens exists: open the cited file/doc at the cited location and confirm the quoted evidence is really there and really means what the finding says; read the whole surrounding function, the file\'s escape helper and the relevant CSS before deciding. Refute if the evidence is misquoted, the behaviour is already handled elsewhere in the same file (an escape helper applied earlier, a guard, a fallback, a CSS override), or the claim rests on a misreading. ' +
    'Lens impact: assume the evidence exists. Would a visitor to the PUBLISHED site (not Editor/Preview), or the person installing these files, actually be affected? Use the Wix loading model in the facts sheet and today\'s slug statuses. Refute if purely theoretical, or if the rated severity is more than one step too high (then set corrected_severity). ' +
    'Lens fix: assume the finding is real. Is the proposed fix correct, minimal and safe on Wix? Set refuted=true ONLY if applying it as written would break something or not fix the issue, and put the right fix in corrected_fix. ' +
    'Default to refuted=true if you cannot confirm. Give confidence high/medium/low and a one-paragraph reason with line numbers.'
}
const W = { high: 1.0, medium: 0.7, low: 0.4 }
async function verify(f) {
  const ls = lensesFor(f.severity)
  const votes = await parallel(ls.map(lens => () =>
    agent(verifyPrompt(f, lens), { label: 'verify:' + lens + ':' + base(f.file) + ':' + (f.line || 0), phase: 'Verify', schema: VERDICT })
      .then(v => v ? Object.assign({ lens }, v) : null)))
  const vs = votes.filter(Boolean)
  const voting = vs.filter(v => v.lens !== 'fix')
  const score = voting.reduce((s, v) => s + (v.refuted ? (W[v.confidence] || 0.4) : 0), 0)
  const killThreshold = voting.length >= 2 ? 1.0 : 0.7
  const alive = voting.length === 0 ? true : score < killThreshold
  const fixVote = vs.find(v => v.lens === 'fix')
  return Object.assign({}, f, {
    verdicts: vs, alive, refuteScore: score, unverified: voting.length === 0,
    fixOk: fixVote ? !fixVote.refuted : null,
    correctedFix: fixVote && fixVote.refuted ? (fixVote.corrected_fix || fixVote.reason) : null,
    correctedSeverity: (voting.map(v => v.corrected_severity).filter(Boolean))[0] || null
  })
}
phase('Verify')
let verified = await parallel(deduped.map(f => () => verify(f)))
verified = verified.filter(Boolean)
let confirmed = verified.filter(f => f.alive)
let killed = verified.filter(f => !f.alive)
log('Verified ' + verified.length + ': ' + confirmed.length + ' confirmed, ' + killed.length + ' refuted')

/* ---- Critique + one gap round ----------------------------------------- */
phase('Critique')
const compact = confirmed.map(f => '[' + f.severity + '] ' + base(f.file) + ':' + f.line + ' ' + f.category + ' -- ' + f.summary).join('\n')
const GAPS = { type: 'object', properties: { gaps: { type: 'array', items: { type: 'object', properties: {
  area: { type: 'string' }, why: { type: 'string' }, how_to_check: { type: 'string' } }, required: ['area','why','how_to_check'] } } }, required: ['gaps'] }
const critique = await agent('You are the completeness critic for an audit of the Arise Church Wix rebuild. Read ' + FACTS + ' and ' + CRAWL + ', list the inventory (' + ROOT + '/files and ' + ROOT + '/files2), and read this list of CONFIRMED findings so far:\n' + compact + '\n\nList what an exhaustive audit would still need to check that this list shows no evidence of covering: files, docs, claims or behaviours left unverified (at most 6), each with a concrete way to check it. Do not re-list known findings. Do not modify files.', { label: 'critic', phase: 'Critique', schema: GAPS })
const gaps = ((critique && critique.gaps) || []).slice(0, 6)
log('Critic named ' + gaps.length + ' gaps')
if (gaps.length) {
  const gapRaw = await parallel(gaps.map((g, i) => () =>
    agent('Investigate this audit gap for the Arise Church Wix rebuild: ' + g.area + ' -- ' + g.why + ' How to check: ' + g.how_to_check + ' . Project root ' + ROOT + ', canonical elements ' + FIXED + '. ' + COMMON + ' Report findings.', { label: 'gap:' + (i + 1), phase: 'Critique', schema: FINDINGS })
      .then(r => ((r && r.findings) || []).map(f => Object.assign({}, f, { finder: 'gap:' + g.area })))))
  const fresh = dedupe(gapRaw.filter(Boolean).flat(), seen)
  fresh.forEach(f => seen.add(f.key))
  log('Gap round: ' + fresh.length + ' new findings to verify')
  const gapVerified = (await parallel(fresh.map(f => () => verify(f)))).filter(Boolean)
  confirmed = confirmed.concat(gapVerified.filter(f => f.alive))
  killed = killed.concat(gapVerified.filter(f => !f.alive))
}

confirmed.sort((a, b) => sevRank(a.severity) - sevRank(b.severity) || (base(a.file) < base(b.file) ? -1 : 1) || (a.line - b.line))
log('DONE: ' + confirmed.length + ' confirmed, ' + killed.length + ' refuted')
return {
  stats: { finders: tasks.length, raw: raw.length, deduped: deduped.length, confirmed: confirmed.length, killed: killed.length, gaps: gaps.length, finderStats },
  confirmed: confirmed.map(f => ({ severity: f.severity, correctedSeverity: f.correctedSeverity, unverified: f.unverified, file: f.file, line: f.line, category: f.category, summary: f.summary, evidence: f.evidence, fix: f.fix, finders: f.finders, refuteScore: f.refuteScore, verdicts: f.verdicts.map(v => v.lens + ':' + (v.refuted ? 'REFUTED' : 'ok') + '/' + v.confidence + ' ' + v.reason) })),
  killed: killed.map(f => ({ severity: f.severity, file: f.file, line: f.line, category: f.category, summary: f.summary, why: f.verdicts.filter(v => v.refuted).map(v => v.lens + ': ' + v.reason) })),
  gaps
}
