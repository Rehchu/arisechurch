export const meta = {
  name: 'arise-cms-hooks',
  description: 'Give every static text block and image in the Arise Church elements a CMS hook, write key manifests, then verify nothing broke',
  phases: [{ title: 'Hook' }, { title: 'Verify' }, { title: 'Repair' }],
}

const ROOT = 'D:/projects/Arise Church Website'
const WORK = ROOT + '/files2/arise-fixed-2026-09-14/custom-elements'
const PREV = ROOT + '/files2/arise-fixed-2026-08-23'
const MAN = ROOT + '/files2/arise-fixed-2026-09-14/cms/manifest'
const CMSREF = ROOT + '/audit/CMS-REFERENCE-2026-09-14.md'

const GROUPS = [
  { key: 'home', files: ['arise-home.js'] },
  { key: 'site-chrome', files: ['arise-header.js', 'arise-footer.js', 'arise-service-times-final.js'] },
  { key: 'contact-serve-form', files: ['arise-contact.js', 'arise-serve.js', 'arise-form.js'] },
  { key: 'connect', files: ['arise-connect.js'] },
  { key: 'leaders-ministries-about', files: ['arise-leaders.js', 'arise-ministries.js', 'arise-about.js'] },
  { key: 'events-sermons-bible', files: ['arise-events.js', 'arise-sermons.js', 'arise-bible.js'] },
  { key: 'galleries', files: ['arise-childrens.js', 'arise-youth.js', 'arise-outreach.js', 'arise-leadnetwork.js'] },
  { key: 'alexandria-creatives-classes', files: ['arise-alexandria.js', 'arise-creatives.js', 'arise-classes.js'] },
]

const PREFIX = {
  'arise-home.js': 'home', 'arise-header.js': 'site.header', 'arise-footer.js': 'site.footer', 'arise-service-times-final.js': 'site.servicetimes',
  'arise-contact.js': 'contact', 'arise-serve.js': 'serve', 'arise-form.js': 'form', 'arise-connect.js': 'connect',
  'arise-leaders.js': 'leaders', 'arise-ministries.js': 'ministries', 'arise-about.js': 'about', 'arise-events.js': 'events',
  'arise-sermons.js': 'sermons', 'arise-bible.js': 'bible', 'arise-childrens.js': 'childrens', 'arise-youth.js': 'youth',
  'arise-outreach.js': 'outreach', 'arise-leadnetwork.js': 'leadnetwork', 'arise-alexandria.js': 'alexandria',
  'arise-creatives.js': 'creatives', 'arise-classes.js': 'classes',
}
const PAGE = {
  'arise-header.js': 'site', 'arise-footer.js': 'site', 'arise-service-times-final.js': 'site',
}

const RULES = `
You are making the Arise Church website (Wix Velo custom elements) fully editable from the Wix CMS. The owner's requirement: "it should use CMS to update text, images, etc." — every piece of page copy and every page image must be changeable from CMS -> Page Content, WITHOUT changing how any page looks or works today.

FILES (already bug-fixed and tested; edit in place): ${WORK}/<file>
Previous version for reference only: ${PREV}/<file>
Existing CMS keys and the collection shape: ${CMSREF} (section "Page Content"). Page Content rows are {contentKey, page, label, text, imageUrl, image, where}. getPageContent() hands every element a map { key: {text, image} } via the data-content attribute, and each element's applyContent() writes text into [data-ck="key"] with innerHTML, images into [data-ci="key"] (IMG src, else background-image), and un-hides [data-ckrow="key"] rows. applyContent only acts when the map has a non-empty value, so a hook whose key has no CMS row keeps its built-in text.

HOW THE SITE WILL BE CHECKED AFTERWARDS (automated, in a browser): every data-ck/data-ci hook is fed a test value and must show it; visible text inside the element that sits under no hook is counted as "uncovered" and must be near zero (text rendered from another CMS collection is exempt when its container has data-cms-source); every element is removed and re-attached and must look identical; importing your manifest rows (text = default) must leave every page pixel-identical in text; zero JS errors.

WHAT TO HOOK — in the markup each file builds (template literals or string concatenation), including empty states, CTA blocks, cards, labels, badges, button and link labels, list items, table/row labels, footnotes, form field LABELS and HINT text and submit-button text that sit in markup, and the success/"thank you" panel copy if it is in markup:
  - text: add data-ck="<key>" to the innermost element whose ENTIRE content is that piece of copy. Its content may include <br>, <b>, <i>, <em>, <strong>, &amp;, &middot;, &rarr; — keep them.
  - images: add data-ci="<key>" to each static <img> (or the element that carries a static background-image URL).
  - text rendered from ANOTHER collection passed in as JSON (leaders list, ministries list, events, serve positions, connect groups, creative departments/members, classes, gallery photos/captions, sermon series values, news items): do NOT hook; instead add data-cms-source="<CollectionName>" to the container element that holds that rendered list/card set (Leaders, Ministries, Events, ServePositions, ConnectGroups, CreativeDepartments, CreativeMembers, OnlinePrograms, Portfolio, SiteSettings, HomeSettings). Hardcoded FALLBACK lists that are shown only when that JSON is missing are part of the same container — mark the container, don't hook each fallback item.
  - the Bible element's search results / verse text come from bible-api.com: mark that results container data-cms-source="BibleAPI".

WHAT NOT TO DO (each of these would break or change the site):
  - Never put data-ck on an element that contains an <input>, <select>, <textarea>, <button>, <img>, <svg>, <video>, <iframe>, another hook, or any child that JS queries by id/class to bind events or update later. If a link or button contains an icon or arrow element plus text, wrap ONLY the text in <span data-ck="...">...</span>. Inline <span> wrappers only — never add block wrappers, never add classes, never change existing classes/ids, never reorder markup.
  - Never hook text that JS rewrites at runtime (rotating slides, tab text set from JS, live badges like "Live Now"/"Latest Service", status messages like "Sending...", validation messages set from JS, counters). Leave them and list them in notes.
  - Do not touch <option> text or values (submitted data), placeholders, alt/aria-label/title attributes, URLs in href.
  - Do not change any existing data-ck/data-ci/data-ckrow key or position. Existing keys stay exactly as they are.
  - Do not change copy. The default text in markup stays byte-for-byte the same.
  - Keep the element self-contained; no new dependencies; iPhone-Safari-15-safe syntax (no ?., ??, class fields). Keep function-style callbacks.
  - If a render method that builds hooked markup does not end with this.applyContent() (or the file's equivalent), add that call at the end of that render path so re-renders pick up CMS values. Make sure applyContent also covers any body-level panel the element appends (header menu panel, service-times panel) — it already does in header and service-times; keep it.
  - Shared facts use the shared site.* keys that already exist: site.times.sunday.main, site.times.sunday.second, site.times.main.glorynight, site.times.main.midweek, site.times.main.prayer, site.times.second.prayer, site.times.second.midweek (and their ".label" keys), site.campus.main, site.campus.second, site.email, site.tagline. A phone number shown as text uses site.phone (new key, default "(318) 640-1865"). Do not create page-specific copies of these facts. Only hook such a fact where its default text in markup is exactly the CMS form; if the markup shows a shortened form (e.g. "10:30 AM" in a row labelled "Sunday"), the existing trim-day logic handles it — keep what the fix pass did.

KEY NAMING: "<prefix>.<section>.<item>" using lowercase letters/digits with dots; camelCase allowed after the first segment; must match /^[a-z0-9]+(\\.[a-zA-Z0-9]+)+$/. Section = the page section in reading order words (hero, who, visit, campus, cta, believe, promise, team, empty, form, success, faq, supplies, ...). Item = heading, kicker, body, body2, button, label, note, item1..itemN, photo, logo, etc. Keys unique within the file; the same key may appear twice in one file only when it is truly the same copy shown twice. Prefix for this file is given below. Department view of arise-creatives uses creatives.dept.*.

MANIFEST: for each file write ${MAN}/<file without .js>.json — a JSON array with ONE entry per key used in that file (existing keys included, new ones included):
  { "contentKey": "...", "page": "<page>", "label": "<short human label, e.g. Hero heading>", "text": "<the exact default content of the hooked element as it will be in the DOM (resolve concatenation; keep <br>, &amp; etc. exactly as written in the markup)>", "imageUrl": "<for data-ci: the full https image URL used by default, else empty>", "where": "<where a volunteer finds it on the page, e.g. Top of page, under the big photo>" }
  For keys whose default is dynamic (e.g. alexandria's T('...') lookups or site.* facts), use the value that renders when there is no CMS row.
  Create the manifest directory if needed. The JSON must be valid (use a small node script to write it if that is easier).

FINISH EACH FILE WITH: node --check "<file>"; node -e to JSON.parse the manifest; grep that customElements.define and every pre-existing data-ck/data-ci/data-ckrow key are still present (compare against: grep -o 'data-c[ki]r\\?o\\?w\\?="[^"]*"' on the version before your edits — copy the file to a temp name before editing so you can diff); add ONE line to the header comment: "CMS hooks 2026-09-14: every text block and image editable via Page Content (see cms/manifest/<name>.json)".

RETURN { files: [{ file, newHooks: number, imageHooks: number, sourceContainers: [string], runtimeTextLeft: [string] }], notes: string }.
`

const HOOK_SCHEMA = {
  type: 'object',
  properties: {
    files: { type: 'array', items: { type: 'object', properties: {
      file: { type: 'string' }, newHooks: { type: 'number' }, imageHooks: { type: 'number' },
      sourceContainers: { type: 'array', items: { type: 'string' } }, runtimeTextLeft: { type: 'array', items: { type: 'string' } } }, required: ['file', 'newHooks'] } },
    notes: { type: 'string' },
  },
  required: ['files', 'notes'],
}
const VERIFY_SCHEMA = {
  type: 'object',
  properties: {
    ok: { type: 'boolean' },
    problems: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, line: { type: 'string' }, problem: { type: 'string' }, how_to_fix: { type: 'string' } }, required: ['file', 'problem', 'how_to_fix'] } },
    summary: { type: 'string' },
  },
  required: ['ok', 'problems', 'summary'],
}

const hookPrompt = (g, extra) => `${RULES}
FILES IN THIS TASK (prefix / page):
${g.files.map((f) => '  ' + f + '  ->  key prefix "' + PREFIX[f] + '", page "' + (PAGE[f] || PREFIX[f]) + '"').join('\n')}
${extra || ''}
Work file by file: read the whole file, list every static text block and image it renders, add the hooks, write the manifest, run the checks.`

const verifyPrompt = (g, rep) => `You are a strict reviewer. Another agent added CMS hooks (data-ck / data-ci / data-cms-source) to Wix Velo custom-element files and wrote manifests. Prove it did not break anything and did the job.
FILES: ${g.files.map((f) => WORK + '/' + f).join(', ')}
MANIFESTS: ${MAN}/<file without .js>.json
BEFORE-HOOKS REFERENCE: the agent may have left temp copies; otherwise compare against the rules and read the diff hunks carefully.
The agent reported: ${JSON.stringify(rep).slice(0, 4000)}
RULES THE AGENT HAD TO FOLLOW (summary): no copy change; hooks only on the innermost element whose entire content is the copy; never on elements containing inputs/buttons/img/svg/video/iframe/other hooks/JS-bound children (wrap text in inline span instead); no class/id/order changes; no hooks on runtime-rewritten text; <option>, placeholders, alt/aria untouched; existing keys unchanged; shared facts use site.* keys; collection-rendered containers get data-cms-source; render paths end with applyContent(); manifest has one entry per key with exact default text; keys match /^[a-z0-9]+(\\.[a-zA-Z0-9]+)+$/; iPhone-safe syntax.
CHECK, for each file:
1. node --check the file. JSON.parse the manifest.
2. Extract every data-ck/data-ci key from the file (grep) and every contentKey from the manifest: both sets must be equal. Report any key in one and not the other.
3. For every manifest entry with text: find the hooked element in the source and confirm the default content matches the manifest text exactly (resolve simple concatenation). Flag mismatches — they would make the CMS import change the page.
4. Scan every new data-ck: is it on an element that contains an input/select/textarea/button/img/svg/video/iframe/another data-ck, or an element whose children JS queries later (look for querySelector('#id' / '.class') usage on descendants)? Is it on text that JS rewrites later (search for textContent/innerHTML assignments targeting that node)? Is a wrapper span placed inside a string in a way that breaks quoting? Any new block wrapper, class, or reordered markup?
5. Is every render method that outputs hooked markup followed by applyContent() (so re-renders pick up CMS values)? Does applyContent search body-level panels where relevant?
6. Were any pre-existing keys renamed/removed? (compare with the 2026-09-14 fix-pass list: the file header comment lists the fixes; keys like site.times.*, home.*, childrens.kids.photo etc. must remain).
7. Obvious remaining static copy with no hook and not under data-cms-source: list up to 10 examples (not a failure unless many).
Return {ok, problems, summary}. ok=false for anything that could break a page or change its text on import. Be concrete (file, line, problem, how_to_fix).`

phase('Hook')
const results = await pipeline(
  GROUPS,
  (g) => agent(hookPrompt(g), { label: 'hook:' + g.key, phase: 'Hook', schema: HOOK_SCHEMA, effort: 'medium' }),
  (rep, g) => agent(verifyPrompt(g, rep), { label: 'verify:' + g.key, phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'medium' }).then((v) => ({ rep, verify: v })),
  async (r, g) => {
    if (!r || !r.verify || r.verify.ok) return Object.assign({}, r, { repaired: false })
    log('repairing ' + g.key + ': ' + r.verify.problems.length + ' problem(s)')
    const repair = await agent(hookPrompt(g, 'A reviewer found these problems in your current edits. Fix exactly these without undoing the rest:\n' + JSON.stringify(r.verify.problems, null, 1)), { label: 'repair:' + g.key, phase: 'Repair', schema: HOOK_SCHEMA, effort: 'medium' })
    const recheck = await agent(verifyPrompt(g, repair), { label: 'recheck:' + g.key, phase: 'Repair', schema: VERIFY_SCHEMA, effort: 'medium' })
    return Object.assign({}, r, { repaired: true, repair: repair, recheck: recheck })
  }
)
return results.map((r, i) => Object.assign({ group: GROUPS[i].key }, r))