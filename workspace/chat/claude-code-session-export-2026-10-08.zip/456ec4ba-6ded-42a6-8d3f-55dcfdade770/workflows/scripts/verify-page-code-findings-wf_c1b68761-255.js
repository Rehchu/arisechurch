export const meta = {
  name: 'verify-page-code-findings',
  description: 'Verify three Velo page-code findings for the Arise Church site against Wix docs and evidence',
  phases: [{ title: 'Docs' }, { title: 'Refute' }],
}

const VERDICT = {
  type: 'object',
  properties: {
    refuted: { type: 'boolean' },
    confidence: { type: 'string', enum: ['low', 'medium', 'high'] },
    reasoning: { type: 'string' },
    alternative_explanations: { type: 'array', items: { type: 'string' } },
    what_would_settle_it: { type: 'string' },
  },
  required: ['refuted', 'confidence', 'reasoning', 'alternative_explanations', 'what_would_settle_it'],
}

const DOCS = {
  type: 'object',
  properties: {
    star_selector_supported: { type: 'string', description: 'Is $w("*") a documented/valid Velo selector? Cite the doc.' },
    id_selection_has_length: { type: 'string', description: 'Does $w("#id") for a single element expose a numeric .length? What does $w("#id") return for an id that does not exist on the page?' },
    select_all_custom_elements: { type: 'string', description: 'The correct selector to get every CustomElement on a page, and what .type returns for one' },
    masterpage_scope: { type: 'string', description: 'Can masterPage.js $w reach page-level elements (not just header/footer), and when' },
    sources: { type: 'array', items: { type: 'string' } },
  },
  required: ['star_selector_supported', 'id_selection_has_length', 'select_all_custom_elements', 'masterpage_scope', 'sources'],
}

const CONTEXT = `
Context: Wix classic Editor site with Velo. Custom elements live in public/custom-elements/. Page code sets JSON attributes on them.
Evidence gathered from the PUBLISHED site (https://www.arisecenla.church) browser console and DOM on 14 Sept 2026:
- masterPage.js (live): fetches getPageContent(), logs "Site content: 45 keys" (this log appears on EVERY page), then runs
    const all = $w('*').filter(e => e.type === '$w.CustomElement'); if (all.length) { all.forEach(el => el.setAttribute('data-content', json)); return; } if (n < 30) setTimeout(() => fill(n+1), 300);
  with no warning when it gives up.
- On /praise-worship, /sermons, /serve, /leaders, /childrens the DOM custom elements <arise-header>, <arise-footer>, <arise-sermons>, <arise-serve>, <arise-childrens> have NO data-content attribute 8+ seconds after load. <arise-leaders> has data-leaders (set by its own page code via $w('#customElement1').setAttribute) so Velo setAttribute DOES reflect into the DOM. <arise-creatives> on /praise-worship has only data-dept="praise-worship" (set in the Editor's attributes panel).
- Praise & Worship page code (live): const EL='#customElement1'; ... logs "Creatives: 6 departments, 14 members" (confirmed in console) then set('data-content'), set('data-depts'), set('data-members') using: const el=$w(EL); if (el && typeof el.setAttribute==='function') {el.setAttribute(...)} else retry 30x300ms with no warning. None of the three attributes appear on the element. The Creative Arts hub page uses '#customElement5' and its element DOES receive data (hub renders 6 department tiles live).
- Past Sermons page code (live): const EL='#customElement1'; $w.onReady(async()=>{ if (!$w(EL).length) { console.warn('Sermons: custom element '+EL+' not found.'); return; } ... }); The console shows "[warn] Sermons: custom element #customElement1 not found." and <arise-sermons> has no attributes.
- Events page code uses $w('#customElement1') with the typeof setAttribute check and logs "Events: rendered"; Ministries and Contact likewise work with '#customElement1'.
`

phase('Docs')
const docs = await agent(`${CONTEXT}
Task: answer these Velo API questions from Wix's official documentation. Use ToolSearch to load the Wix MCP tools (query "select:mcp__a6167f2e-f880-4788-a4e4-6a953223d407__SearchDevelopmentDocumentation,mcp__a6167f2e-f880-4788-a4e4-6a953223d407__ReadFullDocsArticle") and/or WebSearch/WebFetch of wix.com/velo/reference. Questions: (1) Is $w("*") a valid selector? (2) What does $w("#id") return, does it have .length, and what happens for a non-existent id? (3) How do you select every custom element on a page and what does .type return? (4) Does masterPage.js $w reach page-level elements? Cite doc URLs. Be precise; say "not documented" when it is not.`,
  { label: 'velo-docs', phase: 'Docs', schema: DOCS, effort: 'medium' })

phase('Refute')
const claims = [
  { key: 'masterpage-noop', claim: 'The live masterPage.js broadcast is a no-op: $w("*") never yields any element whose .type === "$w.CustomElement", so NO custom element on any page receives data-content from masterPage.js. The fix is to select with $w("CustomElement") (type selector) instead.' },
  { key: 'dept-id-mismatch', claim: 'The six Creative Arts department pages (Praise & Worship, Musicians, Production, Sound, Media, Social Media and Content) never receive data-depts/data-members/data-content because their page code targets "#customElement1" but the custom element on those pages has a different Velo ID (probably "#customElement5", since the pages were duplicated from the Creative Arts hub which uses "#customElement5"). The silent 30-retry loop hides the failure. This is why each page shows the raw slug as its H1 and no department tabs.' },
  { key: 'sermons-length', claim: 'The Past Sermons page code bails out on `if (!$w(EL).length)` because a single-element $w("#id") selection has no .length (undefined) even when the element exists, so the series band and live-stream attributes are never set. Replacing the guard with the typeof-setAttribute retry pattern used on the other pages fixes it regardless of whether the ID is also wrong.' },
]
const verdicts = await parallel(claims.map(c => () =>
  agent(`${CONTEXT}
Velo documentation findings from a previous agent: ${JSON.stringify(docs)}

You are a skeptical reviewer. Try to REFUTE this claim: ${c.claim}
Consider alternative explanations (timing, Velo setAttribute semantics, Editor attribute panel overriding, elements inside iframes, the wrapper element vs the custom element, caching, etc.). You may read local files under "D:/projects/Arise Church Website/files2/live-page-code/" (the live page code) and "D:/projects/Arise Church Website/files/" (element sources). Default to refuted=false only if the evidence genuinely supports the claim; say what single check would settle it.`,
    { label: `refute:${c.key}`, phase: 'Refute', schema: VERDICT, effort: 'medium' })
    .then(v => ({ key: c.key, ...v }))))

return { docs, verdicts: verdicts.filter(Boolean) }